---@class FireBurn
chip = {}

local fire_fx = Engine.load_texture(_folderpath .. "FireFX.png")
local fire_anim = (_folderpath .. "FireFX.animation")

local function create_flame_spell(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(Engine.load_texture(_folderpath .. "flame.png"))
    local animation = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell:set_offset(0, 20)
    spell:highlight_tile(Highlight.Solid)
    animation:load(_folderpath .. "flame.animation")
    animation:set_state("0")
    animation:set_playback(Playback.Loop)
    animation:refresh(spell:sprite())
    spell:set_facing(user:get_facing())
    spell.has_spawned = false
    local tile = nil
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if tile:is_walkable() and props.cracks then
            tile:set_state(TileState.Cracked)
        end
    end
    spell.update_func = function(self, dt)
        tile:attack_entities(self)
    end

    spell.collision_func = function(self, other)
        create_basic_effect(self:get_field(), other:get_tile(), fire_fx, fire_anim, "FIRE")
    end
    return spell
end

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = "FireBrn1"
    props.damage = 70
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Crcks 3 sqrs ahd with fire"
    props.long_description = "Send groundbreaking flames 3 tiles ahead!"

    package:declare_package_id("com.Dawn.card.FireBurn1")
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_codes({ "F", "G", "H", "*" })
end

--- Modified for Old Stove!
---@return {} arr The array of flames, for cleanup
chip.card_create_action = function(user, props)
    local anim = user:get_animation()
    local field = user:get_field()
    local tile_array = {}
    local AUDIO = Engine.load_audio(_folderpath .. "sfx.ogg")
    anim:set_state("FIREBURN")


    local self_tile = user:get_tile()
    local y = self_tile:y()
    local x = self_tile:x()
    local increment = 1
    if user:get_facing() == Direction.Left then increment = -1 end
    for i = 1, 3, 1 do
        local prospective_tile = field:tile_at(x + (i * increment), y)
        if prospective_tile and not prospective_tile:is_edge() then
            table.insert(tile_array, prospective_tile)
        end
    end
    local flame1 = create_flame_spell(user, props)
    local flame2 = create_flame_spell(user, props)
    local flame3 = create_flame_spell(user, props)

    anim:on_frame(1, function()
        Engine.play_audio(AUDIO, AudioPriority.High)
        if #tile_array > 0 then
            field:spawn(flame1, tile_array[1])
        end
    end)

    anim:on_frame(4, function()
        if #tile_array > 1 then
            field:spawn(flame2, tile_array[2])
        end
    end)

    anim:on_frame(7, function()
        if #tile_array > 2 then
            field:spawn(flame3, tile_array[3])
        end
    end)

    anim:on_frame(34, function()
        if flame1.has_spawned then
            flame1:get_animation():set_state("1")
            flame1:get_animation():refresh(flame1:sprite())
            flame1:get_animation():on_complete(function()
                flame1:erase()
            end)
        end
    end)

    anim:on_frame(37, function()
        if flame2.has_spawned then
            flame2:get_animation():set_state("1")
            flame2:get_animation():refresh(flame2:sprite())
            flame2:get_animation():on_complete(function()
                flame2:erase()
            end)
        end
    end)

    anim:on_frame(40, function()
        if flame3.has_spawned then
            flame3:get_animation():set_state("1")
            flame3:get_animation():refresh(flame3:sprite())
            flame3:get_animation():on_complete(function()
                flame3:erase()
            end)
        end
    end)

    anim:on_complete(function(self)
        if not flame1:is_deleted() then flame1:erase() end
        if not flame2:is_deleted() then flame2:erase() end
        if not flame3:is_deleted() then flame3:erase() end
        user.set_state(1)
        user.flames = {}
    end)
    return { flame1, flame2, flame3 }
end


function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end

return chip
